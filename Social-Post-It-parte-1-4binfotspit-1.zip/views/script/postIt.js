
function funzione() {
  document.getElementById("postIt").draggable({
    handle: '.topBar',
  });
}